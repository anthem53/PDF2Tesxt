a = 'StyleGAN2'
b = '''"StyleGAN2"'''

b = a.replace('StyleGAN2','"StyleGAN2"' )

print(b )

a = "kill you baby"
b = a.replace('kill','save')
print(b)